<?php
$string['pluginname'] = 'កាតព័ត៌មានទំនាក់ទំនងគ្រូ';
$string['teacher_contact_card'] = 'កាតព័ត៌មានទំនាក់ទំនងគ្រូ';
$string['teacher_contact_card:addinstance'] = 'បន្ថែមប្លុក កាតព័ត៌មានទំនាក់ទំនងគ្រូ';
$string['teacher_contact_card:myaddinstance'] = 'បន្ថែមប្លុក កាតព័ត៌មានទំនាក់ទំនងគ្រូ ទៅកាន់ Moodle Page របស់ខ្ញុំ';

$string['setting_showassistants'] = 'បង្ហាយជំនួយគ្រូ';
$string['setting_publiclist'] = 'បង្ហាញបញ្ជីគ្រូជាសាធារណៈ';
$string['setting_publiclistdesc'] = 'បង្ហាញបញ្ជីគ្រូជាកាន់សាធារណៈ។​ មានន័យថាសូម្បីតែ guest user ក៏អាចមើលបញ្ជីបានដែរ';
$string['setting_showemail'] = 'បង្ហាញអ៊ីម៉ែលរបស់គ្រូ';
$string['setting_shownumbers'] = 'បង្ហាញលេខរបស់គ្រូ';
$string['setting_cardcolor'] = 'ពណ៌របស់កាត';

$string['tag_teacher'] = 'គ្រូ';
$string['tag_assistant'] = 'ជំនួយគ្រូ';
$string['label_email'] = 'អ៊ីម៉ែល';
$string['label_numbers'] = 'លេខទំនាក់ទំនង';
$string['label_message'] = 'ផ្ញើសារទៅ';
$string['msg_no_number'] = 'មិនមានលេខទំនាកទំនងក្នុងកំណត់ត្រាទេ។';
$string['msg_no_teacher'] = 'មិនមានគ្រូសំរាប់​ Course នេះទេ។';
$string['msg_no_permission'] = 'អ្នកមិនមានសិទ្ធមើលនូវបញ្ជីគ្រូទេ។';
